# Product Showcase UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/TurkAysenur/pen/gORaboY](https://codepen.io/TurkAysenur/pen/gORaboY).

Inspired by Francesco Zagami
https://dribbble.com/shots/15292175-Product-Carousel-Experience
