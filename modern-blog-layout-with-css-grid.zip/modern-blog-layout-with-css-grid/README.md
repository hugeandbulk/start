# Modern Blog Layout with CSS Grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/TurkAysenur/pen/gOmMgpx](https://codepen.io/TurkAysenur/pen/gOmMgpx).

Design by Irakli Nadirashvili
https://dribbble.com/shots/15656415-Blog-Self-Control