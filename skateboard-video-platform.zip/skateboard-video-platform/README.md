# Skateboard Video Platform

A Pen created on CodePen.io. Original URL: [https://codepen.io/TurkAysenur/pen/LYRKpWe](https://codepen.io/TurkAysenur/pen/LYRKpWe).

Inspired by Dwinawan 
https://dribbble.com/shots/14958858--Exploration-Skateboard-Video-Platform/attachments/6676841?mode=media